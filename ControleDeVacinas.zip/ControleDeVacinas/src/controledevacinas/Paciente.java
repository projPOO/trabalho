package controledevacinas;

import java.util.ArrayList;
import java.util.Scanner;

public class Paciente extends Pessoa {

    private String dose1;
    private String dose2;
    private String aplicador;
    private Telefone telefone;
    private Endereco endereco;

    public Paciente() {
        super();
    }

    public String getDose1() {
        return dose1;
    }

    public String getDose2() {
        return dose2;
    }

    public void setDose1(String dose1) {
        this.dose1 = dose1;
    }

    public void setDose2(String dose2) {
        this.dose2 = dose2;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public String getAplicador() {
        return aplicador;
    }

    public void setAplicador(String aplicado) {
        this.aplicador = aplicado;
    }

    public Telefone getTelefone() {
        return telefone;
    }

    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }

    public void cadastrarPaciente(ArrayList<Paciente> pacientes, Scanner teclado, Paciente p) {

        Telefone t = new Telefone();
        Endereco e = new Endereco();
        System.out.println("------------------");
        System.out.println("Cadastrar PACIENTE");
        System.out.println("------------------");
        System.out.println("Informe o Nome:");
        p.nome = teclado.next();
        System.out.println("Informe o CPF:");
        p.cpf = teclado.next();
        System.out.println("Informe a Idade:");
        p.idade = teclado.nextInt();

        //Telefone
        System.out.println("-------Telefone-------");
        System.out.println("Informe o tipo do Telefone:");
        t.setTipo(teclado.next());
        System.out.println("Informe o DDD:");
        t.setDdd(teclado.next());
        System.out.println("Informe o numero:");
        t.setNumero(teclado.next());
        p.setTelefone(t);

        //Endereço
        System.out.println("-------Endereço-------");
        System.out.println("Informe a Rua:");
        e.setRua(teclado.next());
        System.out.println("Informe a Cidade:");
        e.setCidade(teclado.next());
        System.out.println("Informe o Estado:");
        e.setEstado(teclado.next());
        System.out.println("Informe o cep:");
        e.setCep(teclado.next());
        p.setEndereco(e);

        pacientes.add(p);

    }

    public int estatisticas(Scanner teclado, Paciente p) {
        int tomou, tomou2, opcao;
        System.out.println("O paciente ja tomou a primeira DOSE?");
        System.out.println(" (Digite 1 para SIM e 2 para NÃO)");
        tomou = teclado.nextInt(); 
         if (tomou == 1) {
            p.dose1 = "OK!";
            System.out.println("O paciente ja tomou a segunda DOSE?");
            System.out.println(" (Digite 1 para SIM e 2 para NÃO)");
            tomou2 = teclado.nextInt();
            if (tomou2 == 1) {
                p.dose2 = "OK!";
                return 2;

            } else if (tomou2 == 2){
                System.out.println("Informe a Data para marcação da Segunda DOSE:");
                p.dose2 = teclado.next();
                return 1;      
                }
            }else {
             System.out.println("Informe a Data para marcação da Primeira DOSE:");
        p.dose1 = teclado.next();
        p.dose2 = " - ";
        return 3;
         }
        return 1;

        }
        
    
       

 
       

    public void imprimir(ArrayList<Paciente> pacientes) {
        int i = 1;
        System.out.println("-------------------------------------");
        System.out.println("Total de Pacientes Cadastrados :" + pacientes.size());
        System.out.println("-------------------------------------");
        for (Paciente p1 : pacientes) {
            System.out.println(i++ + "- Nome     : " + p1.nome);
            System.out.println("   CPF      : " + p1.cpf);
            System.out.println("   Idade    : " + p1.idade);
            System.out.println("   Telefone : " + p1.telefone.getTipo() + " - (" + p1.telefone.getDdd() + ") " + p1.telefone.getNumero());
            System.out.println("   Endereco : " + p1.endereco.getCep() + " - " + p1.endereco.getEstado() + " - " + p1.endereco.getCidade() + " - " + p1.endereco.getRua());
            System.out.println("   Dose 1   : " + p1.dose1);
            System.out.println("   Dose 2   : " + p1.dose2);
            System.out.println("-------------------------------------");

        }

    }

}
